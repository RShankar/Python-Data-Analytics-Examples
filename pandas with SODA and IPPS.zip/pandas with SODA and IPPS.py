# -*- coding: utf-8 -*-
"""
Used Spyder Editor from Anaconda Navigator

This is a how-to document to access IPPS database with 
SODA API and using Pandas dataframe in Python.
"""


#https://data.cms.gov/Medicare-Inpatient/Inpatient-Prospective-Payment-System-IPPS-Provider/97k6-zzx3
#https://dev.socrata.com/blog/2016/02/01/pandas-and-jupyter-notebook.html
#https://pandas.pydata.org/pandas-docs/stable/dsintro.html
#http://pythonhow.com/pandas-data-analysis-functions/

import pandas as pd
print(pd.__version__)
# Reading Inpatient Prospective Payment System (IPPS) 
# Provider Summary for the Top 100 Diagnosis-Related Groups (DRG) - FY2011
df = pd.read_json("https://data.cms.gov/resource/ehrv-m9r6.json")
df.head(5) # first five rows
df.shape # number of rows and columns
df.describe() # only numeric types
df.dtypes
df.describe(include = "all") # summary of both alpha and numeric types
df.provider_zip_code # list that column
df.index # range of rows
df.columns # names of columns
df["provider_state"]
df.loc[1:10] # the first 10 rows
df2 = df.set_index("provider_state") #new dataframe with state as index
df2.loc["FL"] # list only "FL" hospitals
df2.loc["FL", "total_discharges" ] # list only "FL" hospitals' total discharges
df2.loc[:, "total_discharges" ] # list for all states total discharges
df.iloc[0:3, 0:4] # original dataframe, first 3 rows, first 4 columns, 1 less than index
df2.iloc[0:3, 0:4] #df2 lists state name instead of row index.
dir(pd.DataFrame) # lists all the functions available
help(pd.DataFrame.mean) #help on a specific function
df2.loc["FL"].count() # use of count function
df2.loc["FL"].mean() # averages for "FL" state
df3 = df.groupby(["provider_state"]).mean() # averages for each state
df3.shape # it has data for 47 "states" inclusive of DC, but not 4 states with "W"
df3.loc["Mean"] = df3.mean(axis=0) # add a row ("Mean") to the list of states with mean values
df3.loc["Mean"] #list them

#mapping function similar to the one from SODA tutorial
def AboveAvgCost(x):
    if x >= df3.loc["Mean", "average_covered_charges"]:
        return 1
    else:
        return 0
    
df3['above_avg_cost'] = df3.average_covered_charges.apply(AboveAvgCost)
df3 # list which state has above avg cost
df3.above_avg_cost.value_counts() # 19 are above avg cost
df3.loc[:, "above_avg_cost"]
df3.loc[:, "above_avg_cost"].eq(0) # converts 1 and 0 to boolean
df3.loc[:, "above_avg_cost"].bool # converts to 1 and 0
# to do: list the subset that has above avg cost
# may have to use isin as here
#https://stackoverflow.com/questions/25025621/check-for-value-in-list-of-pandas-data-frame-columns
    
